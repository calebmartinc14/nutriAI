# Propuesta de nueva web · AyudArte Educativo

Versión renovada de **ayudarteeducativo.es**, hecha para que el negocio tenga una web
moderna, rápida y profesional **sin depender del Kit Digital ni de cuotas mensuales**.

---

## 🎯 El argumento de venta (por qué cambiar)

| Web actual (WordPress + Kit Digital) | Web nueva (esta propuesta) |
|---|---|
| Pago/justificación atado a la subvención Kit Digital | **Sin cuotas**: un solo archivo, se aloja casi gratis |
| WordPress = plugins, actualizaciones y posibles fallos | HTML/CSS/JS puro, **cero mantenimiento técnico** |
| Carga más lenta (temas + plugins) | **Carga casi instantánea**, ideal para móvil |
| SEO básico | **SEO optimizado** (metaetiquetas, Open Graph y datos estructurados de Google) |
| Sin captación directa clara | **Botón de WhatsApp flotante** + formulario que abre WhatsApp con el mensaje ya escrito |

> **Mensaje para el dueño:** «Te dejo una web más rápida, más bonita y que capta más
> clientes, y además te quitas el gasto recurrente del Kit Digital. La pagas una vez y es tuya.»

---

## ✨ Mejoras incluidas

- **Diseño moderno y cálido** acorde a una educación inclusiva (verde confianza + ámbar “arte”).
- **100% responsive**: se ve perfecta en móvil, tablet y ordenador.
- **Accesibilidad**: etiquetas ARIA, foco visible, buen contraste y respeto a “reducir movimiento”.
- **Secciones nuevas y mejor ordenadas**: hero, datos clave, servicios, quiénes somos,
  cómo trabajamos (método en 4 pasos), opiniones, preguntas frecuentes, llamada a la acción y contacto.
- **Captación de clientes**: WhatsApp flotante, botones de llamada y formulario inteligente.
- **SEO + Google**: datos estructurados `EducationalOrganization` para aparecer mejor en búsquedas locales.
- **Rendimiento**: sin imágenes pesadas (ilustraciones SVG), sin librerías externas salvo la tipografía.

Todo el contenido (servicios, testimonios, FAQ, contacto) está tomado de la web real
para que el dueño lo reconozca al instante.

---

## 🚀 Cómo verla y cómo publicarla

**Verla en local:** abre `index.html` con doble clic (o ejecuta `node server.js` y entra en
`http://localhost:4599`).

**Publicarla (opciones, todas muy baratas o gratis):**
- **Netlify / Cloudflare Pages / GitHub Pages**: arrastras la carpeta y queda online gratis con HTTPS.
- **Hosting propio del dueño**: subir `index.html` por FTP. Nada más.
- Apuntar el dominio actual `ayudarteeducativo.es` al nuevo alojamiento cuando lo apruebe.

---

## 🔧 Pendiente de personalizar antes de entregar

- Sustituir las **ilustraciones SVG** por fotos reales del equipo/centro si las tienen.
- Colocar el **logo oficial** en la cabecera (ahora hay un wordmark “AyudArte”).
- Conectar el **formulario** a un email real (FormSubmit/Formspree) si no se quiere usar solo WhatsApp.
- Rellenar **Aviso legal, Política de privacidad y Cookies** (obligatorio en España, RGPD/LSSI).
- Confirmar datos: teléfono **687 21 99 97**, email, dirección y redes.

---

*Preparado por CLB Informática.*
